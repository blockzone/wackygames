"use client";

import React from "react";
import Link from "next/link";
import { Separator } from "@/components/ui/separator";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0f1018] border-t border-gray-800 py-6">
      <div className="container">
        <div className="flex flex-wrap gap-4 justify-center md:justify-between mb-6">
          <div className="flex flex-wrap gap-4 text-sm text-gray-400">
            <Link href="/about" className="hover:text-white">About</Link>
            <Link href="/developers" className="hover:text-white">Developers</Link>
            <Link href="/kids" className="hover:text-white">Kids site</Link>
            <Link href="/jobs" className="hover:text-white">Jobs</Link>
            <Link href="/parents" className="hover:text-white">Info for parents</Link>
            <Link href="/terms" className="hover:text-white">Terms & conditions</Link>
            <Link href="/privacy" className="hover:text-white">Privacy</Link>
            <Link href="/sitemap" className="hover:text-white">All games</Link>
          </div>
          <div className="flex gap-4">
            <Link href="https://www.tiktok.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"></path>
                <path d="M15 8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"></path>
                <path d="M15 8v4"></path>
                <path d="M15 12h-3"></path>
              </svg>
            </Link>
            <Link href="https://discord.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 9v.01"></path>
                <path d="M15 15v.01"></path>
                <path d="M15 9v.01"></path>
                <path d="M9 15v.01"></path>
                <path d="M5 5h14v14H5z"></path>
              </svg>
            </Link>
            <Link href="https://www.linkedin.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                <rect x="2" y="9" width="4" height="12"></rect>
                <circle cx="4" cy="4" r="2"></circle>
              </svg>
            </Link>
            <Link href="https://www.youtube.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
              </svg>
            </Link>
            <Link href="https://play.google.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z"></path>
                <path d="m13 13 6 6"></path>
              </svg>
            </Link>
            <Link href="https://apps.apple.com" className="text-gray-400 hover:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a9 9 0 0 1 9 9c0 3.3-1.8 6.3-4.5 7.9-1 .6-1.5-.4-1.5-.9V15h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-2V6c0-.5.5-1.5 1.5-.9A9 9 0 0 1 12 2Z"></path>
                <path d="M9.1 9H7a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2v3a2 2 0 0 1-4 0v-4.8"></path>
              </svg>
            </Link>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4 text-sm">
          <div className="flex flex-wrap gap-2 justify-center">
            <span className="text-gray-500">English</span>
            <Separator orientation="vertical" className="h-4 bg-gray-800" />
            <Link href="#" className="text-gray-400 hover:text-white">Čeština</Link>
            <Link href="#" className="text-gray-400 hover:text-white">Dansk</Link>
            <Link href="#" className="text-gray-400 hover:text-white">Deutsch</Link>
            <Link href="#" className="text-gray-400 hover:text-white">Español</Link>
            <Link href="#" className="text-gray-400 hover:text-white">Français</Link>
          </div>
        </div>

        <div className="text-center mt-6 text-gray-500 text-sm">
          © {currentYear} CrazyGames
        </div>
      </div>
    </footer>
  );
}
