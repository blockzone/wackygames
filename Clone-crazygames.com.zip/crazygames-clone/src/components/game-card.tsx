"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";

interface GameCardProps {
  id: string;
  title: string;
  imageUrl: string;
  isNew?: boolean;
  isFeatured?: boolean;
  width?: "normal" | "large";
}

export function GameCard({
  id,
  title,
  imageUrl,
  isNew = false,
  isFeatured = false,
  width = "normal",
}: GameCardProps) {
  return (
    <Link href={`/game/${id}`} className={`game-card ${width === "large" ? "md:col-span-2" : ""}`}>
      <div className="relative overflow-hidden rounded-xl">
        <Image
          src={imageUrl}
          alt={title}
          width={width === "large" ? 675 : 273}
          height={width === "large" ? 380 : 153}
          className={`w-full ${width === "large" ? "aspect-video" : "aspect-video"} object-cover`}
        />
        {isNew && <div className="new-badge">NEW</div>}
        {isFeatured && (
          <div className="absolute top-2 left-2 bg-cg-teal text-white text-xs font-bold px-2 py-1 rounded">
            FEATURED
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end p-3">
          <h3 className="text-white font-bold text-sm">{title}</h3>
        </div>
      </div>
    </Link>
  );
}
