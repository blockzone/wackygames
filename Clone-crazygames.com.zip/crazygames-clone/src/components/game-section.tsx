"use client";

import React from "react";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { GameCard } from "@/components/game-card";

interface Game {
  id: string;
  title: string;
  imageUrl: string;
  isNew?: boolean;
  isFeatured?: boolean;
}

interface GameSectionProps {
  title: string;
  games: Game[];
  viewAllLink?: string;
  layout?: "grid" | "featured";
}

export function GameSection({
  title,
  games,
  viewAllLink,
  layout = "grid",
}: GameSectionProps) {
  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">{title}</h2>
        {viewAllLink && (
          <Link
            href={viewAllLink}
            className="text-sm text-gray-400 hover:text-white flex items-center"
          >
            View more <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        )}
      </div>

      {layout === "grid" ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {games.map((game) => (
            <GameCard
              key={game.id}
              id={game.id}
              title={game.title}
              imageUrl={game.imageUrl}
              isNew={game.isNew}
              isFeatured={game.isFeatured}
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {games[0] && (
            <div className="md:col-span-2">
              <GameCard
                id={games[0].id}
                title={games[0].title}
                imageUrl={games[0].imageUrl}
                isNew={games[0].isNew}
                isFeatured={games[0].isFeatured}
                width="large"
              />
            </div>
          )}
          <div className="grid grid-cols-2 md:grid-cols-1 gap-4">
            {games.slice(1, 3).map((game) => (
              <GameCard
                key={game.id}
                id={game.id}
                title={game.title}
                imageUrl={game.imageUrl}
                isNew={game.isNew}
                isFeatured={game.isFeatured}
              />
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
