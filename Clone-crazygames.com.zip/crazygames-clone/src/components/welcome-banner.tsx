"use client";

import React from "react";
import Image from "next/image";
import { Gamepad, Monitor, DownloadCloud, Users, BadgeDollarSign } from "lucide-react";

export function WelcomeBanner() {
  return (
    <div className="relative w-full bg-gradient-to-b from-[#14141c] to-[#0f1018] rounded-xl p-6 mb-8">
      <div className="flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <Image
            src="https://ext.same-assets.com/2519731525/1248550479.svg"
            alt="CrazyGames Logo"
            width={48}
            height={48}
            className="mr-3"
          />
          <h1 className="text-2xl font-bold">Welcome to CrazyGames</h1>
        </div>

        <div className="flex flex-wrap justify-center md:justify-end gap-4">
          <div className="flex items-center text-gray-300 text-sm">
            <Gamepad className="h-4 w-4 mr-2 text-cg-purple" />
            <span>4000+ games</span>
          </div>

          <div className="flex items-center text-gray-300 text-sm">
            <DownloadCloud className="h-4 w-4 mr-2 text-cg-purple" />
            <span>No install needed</span>
          </div>

          <div className="flex items-center text-gray-300 text-sm">
            <Monitor className="h-4 w-4 mr-2 text-cg-purple" />
            <span>On any device</span>
          </div>

          <div className="flex items-center text-gray-300 text-sm">
            <Users className="h-4 w-4 mr-2 text-cg-purple" />
            <span>Play with friends</span>
          </div>

          <div className="flex items-center text-gray-300 text-sm">
            <BadgeDollarSign className="h-4 w-4 mr-2 text-cg-purple" />
            <span>All for free</span>
          </div>
        </div>
      </div>
    </div>
  );
}
