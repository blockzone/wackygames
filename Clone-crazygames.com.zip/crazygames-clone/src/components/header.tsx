"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Search, User, Heart, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full bg-[#0f1018] border-b border-gray-800">
      <div className="container flex h-14 items-center">
        <div className="flex items-center mr-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="bg-[#0f1018] p-0">
              <div className="h-full flex flex-col">
                <div className="p-4 border-b border-gray-800">
                  <Link href="/" className="flex items-center">
                    <Image
                      src="https://ext.same-assets.com/2519731525/1248550479.svg"
                      alt="CrazyGames Logo"
                      width={36}
                      height={36}
                      className="mr-2"
                    />
                    <span className="text-lg font-bold">CrazyGames</span>
                  </Link>
                </div>
                <nav className="flex-1 p-4 space-y-4 overflow-y-auto">
                  <div className="space-y-2">
                    <Link href="/" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">🏠</span> Home
                    </Link>
                    <Link href="/new" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">🆕</span> New
                    </Link>
                    <Link href="/hot" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">🔥</span> Trending now
                    </Link>
                    <Link href="/updated" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">🔄</span> Updated
                    </Link>
                    <Link href="/originals" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">✨</span> Originals
                    </Link>
                    <Link href="/multiplayer" className="flex items-center text-sm hover:text-white">
                      <span className="mr-2">👥</span> Multiplayer
                    </Link>
                  </div>
                </nav>
              </div>
            </SheetContent>
          </Sheet>

          <Link href="/" className="flex items-center space-x-2">
            <div className="flex items-center">
              <Image
                src="https://ext.same-assets.com/2519731525/1248550479.svg"
                alt="CrazyGames Logo"
                width={36}
                height={36}
                className="mr-2"
              />
              <span className="text-lg font-bold hidden md:inline-block">
                CrazyGames
              </span>
            </div>
          </Link>
        </div>

        <div className="flex-1 mx-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              type="search"
              placeholder="Search"
              className="w-full bg-[#14141c] border-none pl-9 rounded-md h-9"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="hidden md:flex">
            <Heart className="h-5 w-5" />
          </Button>
          <Button className="bg-cg-purple hover:bg-cg-primary text-white">
            Log in
          </Button>
        </div>
      </div>
    </header>
  );
}
