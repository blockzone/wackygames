"use client";

import React from "react";
import Link from "next/link";
import {
  Home,
  Clock,
  TrendingUp,
  RefreshCw,
  Sparkles,
  Users,
  Gamepad2,
  Sword,
  Mountain,
  Basketball,
  Shirt,
  Bike,
  Car,
  Heart,
  Armchair,
  MousePointerClick,
  Joystick,
  Scissors,
  Ghost,
  Target,
  Rocket,
  Dices,
  Puzzle,
  Crosshair,
  Footprints,
  Gamepad
} from "lucide-react";

const categories = [
  { name: "Home", icon: <Home className="w-5 h-5" />, href: "/" },
  { name: "Recently Played", icon: <Clock className="w-5 h-5" />, href: "/recent" },
  { name: "New", icon: <Sparkles className="w-5 h-5" />, href: "/new" },
  { name: "Trending Now", icon: <TrendingUp className="w-5 h-5" />, href: "/hot" },
  { name: "Updated", icon: <RefreshCw className="w-5 h-5" />, href: "/updated" },
  { name: "Originals", icon: <Sparkles className="w-5 h-5" />, href: "/originals" },
  { name: "Multiplayer", icon: <Users className="w-5 h-5" />, href: "/multiplayer" },
  { name: "2 Player", icon: <Users className="w-5 h-5" />, href: "/2-player" },
  { name: "Action", icon: <Sword className="w-5 h-5" />, href: "/action" },
  { name: "Adventure", icon: <Mountain className="w-5 h-5" />, href: "/adventure" },
  { name: "Basketball", icon: <Basketball className="w-5 h-5" />, href: "/basketball" },
  { name: "Beauty", icon: <Scissors className="w-5 h-5" />, href: "/beauty" },
  { name: "Bike", icon: <Bike className="w-5 h-5" />, href: "/bike" },
  { name: "Car", icon: <Car className="w-5 h-5" />, href: "/car" },
  { name: "Card", icon: <Heart className="w-5 h-5" />, href: "/card" },
  { name: "Casual", icon: <Armchair className="w-5 h-5" />, href: "/casual" },
  { name: "Clicker", icon: <MousePointerClick className="w-5 h-5" />, href: "/clicker" },
  { name: "Controller", icon: <Joystick className="w-5 h-5" />, href: "/controller" },
  { name: "Horror", icon: <Ghost className="w-5 h-5" />, href: "/horror" },
  { name: ".io", icon: <Target className="w-5 h-5" />, href: "/io" },
  { name: "Puzzle", icon: <Puzzle className="w-5 h-5" />, href: "/puzzle" },
  { name: "Shooting", icon: <Crosshair className="w-5 h-5" />, href: "/shooting" },
  { name: "Sports", icon: <Footprints className="w-5 h-5" />, href: "/sports" },
];

export function Sidebar() {
  return (
    <div className="hidden md:flex flex-col w-14 shrink-0 border-r border-gray-800 h-[calc(100vh-3.5rem)] sticky top-14 overflow-y-auto scrollbar-none">
      {categories.map((category) => (
        <Link
          key={category.name}
          href={category.href}
          className="flex flex-col items-center justify-center p-2 hover:bg-gray-800 transition-colors"
        >
          <div className="text-gray-400 hover:text-white">
            {category.icon}
          </div>
          <span className="text-xs text-gray-400 mt-1 text-center">
            {category.name}
          </span>
        </Link>
      ))}
    </div>
  );
}
