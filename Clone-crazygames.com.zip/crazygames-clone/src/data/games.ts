// Sample games data based on CrazyGames

export interface Game {
  id: string;
  title: string;
  description?: string;
  imageUrl: string;
  category: string[];
  isNew?: boolean;
  isFeatured?: boolean;
  rating?: number;
  ratingCount?: number;
  developer?: string;
  releaseDate?: string;
  lastUpdated?: string;
  technology?: string;
  platform?: string;
}

export const featuredGames: Game[] = [
  {
    id: "bloxd-io",
    title: "Bloxd.io",
    description: "A multiplayer block building game",
    imageUrl: "https://imgs.crazygames.com/games/bloxdhop-io/cover_16x9-1709115453824.png?metadata=none&quality=85&width=675&fit=crop",
    category: ["multiplayer", "building", "io"],
    isFeatured: true,
    rating: 8.7,
    ratingCount: 150000,
    developer: "Bloxd Studios",
    releaseDate: "April 2023",
    lastUpdated: "February 2024",
    technology: "HTML5",
    platform: "Browser (desktop, mobile, tablet)",
  },
  {
    id: "ragdoll-archers",
    title: "Ragdoll Archers",
    description: "Physics-based archery game",
    imageUrl: "https://imgs.crazygames.com/ragdoll-archers_16x9/20240205020743/ragdoll-archers_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["action", "physics", "ragdoll"],
    isNew: true,
    rating: 8.5,
    ratingCount: 95000,
    developer: "Crazy Labs",
    releaseDate: "January 2024",
    lastUpdated: "February 2024",
    technology: "HTML5",
    platform: "Browser (desktop, mobile, tablet)",
  },
  {
    id: "slice-master",
    title: "Slice Master",
    description: "Slice everything in sight with precision",
    imageUrl: "https://imgs.crazygames.com/slice-master_16x9/20240731033229/slice-master_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["action", "casual", "one-button"],
    isNew: true,
    rating: 8.3,
    ratingCount: 568595,
    developer: "PlayCalm",
    releaseDate: "April 2024",
    lastUpdated: "July 2024",
    technology: "HTML5",
    platform: "Browser (desktop, mobile, tablet)",
  },
  {
    id: "polytrack",
    title: "PolyTrack",
    description: "Race in low-poly tracks",
    imageUrl: "https://imgs.crazygames.com/polytrack_16x9/20240814074159/polytrack_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["racing", "3d", "driving"],
    isNew: true,
    rating: 7.9,
    ratingCount: 42000,
    developer: "PolyFun Games",
    releaseDate: "March 2024",
    lastUpdated: "August 2024",
    technology: "HTML5",
    platform: "Browser (desktop, mobile, tablet)",
  },
  {
    id: "count-masters",
    title: "Count Masters: Stickman Games",
    description: "Multiply your stickman army",
    imageUrl: "https://imgs.crazygames.com/count-masters-stickman-games_16x9/20250220041115/count-masters-stickman-games_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["casual", "action", "stickman"],
    rating: 8.1,
    ratingCount: 125000,
    developer: "RapidGames",
    releaseDate: "December 2023",
    lastUpdated: "February 2024",
    technology: "HTML5",
    platform: "Browser (desktop, mobile, tablet)",
  },
];

export const recentGames: Game[] = [
  {
    id: "crazy-flips-3d",
    title: "Crazy Flips 3D",
    imageUrl: "https://imgs.crazygames.com/games/crazy-flips-3d/cover_16x9-1717520212223.png?metadata=none&quality=85&width=273&fit=crop",
    category: ["action", "3d", "physics"],
    isNew: true,
    rating: 8.2,
    ratingCount: 58000,
  },
  {
    id: "mahjongg-solitaire",
    title: "Mahjongg Solitaire",
    imageUrl: "https://imgs.crazygames.com/games/mahjongg-solitaire/cover_16x9-1707829450935.png?metadata=none&quality=85&width=273&fit=crop",
    category: ["puzzle", "strategy", "board"],
    rating: 8.6,
    ratingCount: 126000,
  },
  {
    id: "corn-tycoon",
    title: "Corn Tycoon",
    imageUrl: "https://imgs.crazygames.com/corn-tycoon_16x9/20250303071102/corn-tycoon_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["simulation", "tycoon", "building"],
    isNew: true,
    rating: 7.8,
    ratingCount: 32000,
  },
  {
    id: "golf-orbit",
    title: "Golf Orbit",
    imageUrl: "https://imgs.crazygames.com/golf-orbit_16x9/20240620070701/golf-orbit_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["sports", "golf", "physics"],
    rating: 8.4,
    ratingCount: 85000,
  },
];

export const popularGames: Game[] = [
  {
    id: "planet-smash-destruction",
    title: "Planet Smash Destruction",
    imageUrl: "https://imgs.crazygames.com/solar-smash_16x9/20240722073047/solar-smash_16x9-cover?metadata=none&quality=85&width=675&fit=crop",
    category: ["simulation", "destruction", "physics"],
    rating: 8.9,
    ratingCount: 240000,
  },
  {
    id: "worldguessr",
    title: "WorldGuessr Free GeoGuessr",
    imageUrl: "https://imgs.crazygames.com/worldguessr_16x9/20241018082520/worldguessr_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["geography", "quiz", "educational"],
    rating: 9.1,
    ratingCount: 320000,
  },
  {
    id: "racing-limits",
    title: "Racing Limits",
    imageUrl: "https://imgs.crazygames.com/racing-limits_16x9/20231106035424/racing-limits_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["racing", "car", "action"],
    rating: 8.7,
    ratingCount: 175000,
  },
  {
    id: "basketball-superstars",
    title: "Basketball Superstars",
    imageUrl: "https://imgs.crazygames.com/basketball-superstars_16x9/20250117063641/basketball-superstars_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["sports", "basketball", "arcade"],
    rating: 8.2,
    ratingCount: 92000,
  },
  {
    id: "guess-their-answer",
    title: "Guess Their Answer",
    imageUrl: "https://imgs.crazygames.com/guess-their-answer_16x9/20241122084004/guess-their-answer_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["quiz", "puzzle", "multiplayer"],
    rating: 8.3,
    ratingCount: 68000,
  },
];

export const trendingGames: Game[] = [
  {
    id: "rpg-idle-clicker",
    title: "RPG Idle Clicker",
    imageUrl: "https://imgs.crazygames.com/rpg-idle-clicker-uzz_16x9/20250319111034/rpg-idle-clicker-uzz_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["rpg", "idle", "clicker"],
    isNew: true,
    rating: 8.5,
    ratingCount: 85000,
  },
  {
    id: "knock-and-run",
    title: "Knock and Run: 100 Doors Escape",
    imageUrl: "https://imgs.crazygames.com/knock-and-run_16x9/20250320160406/knock-and-run_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["escape", "puzzle", "adventure"],
    isNew: true,
    rating: 8.7,
    ratingCount: 102000,
  },
  {
    id: "playground-man",
    title: "Playground Man! Ragdoll Show!",
    imageUrl: "https://imgs.crazygames.com/ragdoll-break_16x9/20250311102953/ragdoll-break_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["ragdoll", "physics", "funny"],
    rating: 8.3,
    ratingCount: 76000,
  },
  {
    id: "idle-saga",
    title: "Idle Saga",
    imageUrl: "https://imgs.crazygames.com/idle-saga_16x9/20250305045349/idle-saga_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["idle", "strategy", "rpg"],
    rating: 8.6,
    ratingCount: 94000,
  },
  {
    id: "empire-clicker",
    title: "Empire Clicker",
    imageUrl: "https://imgs.crazygames.com/empire-clicker_16x9/20250321082625/empire-clicker_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["clicker", "strategy", "building"],
    isNew: true,
    rating: 8.8,
    ratingCount: 120000,
  },
];

export const ioGames: Game[] = [
  {
    id: "shell-shockers",
    title: "Shell Shockers",
    imageUrl: "https://imgs.crazygames.com/shellshockersio_16x9/20250319203901/shellshockersio_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["io", "shooting", "multiplayer"],
    rating: 9.2,
    ratingCount: 520000,
  },
  {
    id: "smash-karts",
    title: "Smash Karts",
    imageUrl: "https://imgs.crazygames.com/smash-karts_16x9/20250321154634/smash-karts_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["io", "racing", "multiplayer"],
    rating: 9.0,
    ratingCount: 480000,
  },
  {
    id: "farm-merge-valley",
    title: "Farm Merge Valley",
    imageUrl: "https://imgs.crazygames.com/farm-merge-valley_16x9/20250317164207/farm-merge-valley_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["merge", "farming", "simulation"],
    isNew: true,
    rating: 8.5,
    ratingCount: 65000,
  },
  {
    id: "8-ball-billiards",
    title: "8 Ball Billiards Classic",
    imageUrl: "https://imgs.crazygames.com/8-ball-billiards-classic_16x9/20231108025958/8-ball-billiards-classic_16x9-cover?metadata=none&quality=85&width=273&fit=crop",
    category: ["sports", "pool", "multiplayer"],
    rating: 8.8,
    ratingCount: 310000,
  },
];

export const allGames = [
  ...featuredGames,
  ...recentGames,
  ...popularGames,
  ...trendingGames,
  ...ioGames,
];
