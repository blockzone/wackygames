import { HomeLayout } from "@/components/home-layout";
import { WelcomeBanner } from "@/components/welcome-banner";
import { GameSection } from "@/components/game-section";
import {
  featuredGames,
  trendingGames,
  recentGames,
  popularGames,
  ioGames
} from "@/data/games";

export default function HomePage() {
  return (
    <HomeLayout>
      <WelcomeBanner />

      <GameSection
        title="Featured Games"
        games={featuredGames.slice(0, 5)}
        layout="featured"
        viewAllLink="/featured"
      />

      <GameSection
        title="Recently Played"
        games={recentGames.slice(0, 5)}
        viewAllLink="/recent"
      />

      <GameSection
        title="Popular Games"
        games={popularGames.slice(0, 5)}
        viewAllLink="/popular"
      />

      <GameSection
        title="Trending Games"
        games={trendingGames.slice(0, 5)}
        viewAllLink="/trending"
      />

      <GameSection
        title="IO Games"
        games={ioGames.slice(0, 5)}
        viewAllLink="/io"
      />
    </HomeLayout>
  );
}
